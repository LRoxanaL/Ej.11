botonDia = document.querySelector('.buttonDia');
botonDia.addEventListener('click', analizarDia);

function analizarDia(e) {
    e.preventDefault();
    const diaSemana = document.querySelector('.inputdia')
    
    switch (diaSemana.value.toLowerCase()) {
        case "lunes":
            alert("Hoy es lunes.Entrenamiento suave: 1h de caminata");
            break;
        case "martes":
            alert("Hoy es martes. Entrenamiento de glúteos y piernas de 1h 30 min");
            break;
        case "miércoles":
            alert("Hoy es miércoles. Entrenamiento de brazos y pectorales: 1h 30 min");
            break;
        case "jueves":
            alert("Hoy es jueves. Entrenamiento de abdominales: 2hs");
            break;
        case "viernes":
            alert("Hoy es viernes. Bicicleteada de 2hs");
            break;
        case "sábado":
            alert("Hoy es sábado. Caminata y trote combinados de 2hs");
            break;
        case "domingo":
            alert("Hoy es domingo. Descanso y relajación");
            break;
        default:
            alert("Escribe correctamente el día de la semana.");
    }
    diaSemana.value = "Suerte"; 
}

